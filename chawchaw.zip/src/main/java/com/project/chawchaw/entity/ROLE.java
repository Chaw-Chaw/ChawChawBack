package com.project.chawchaw.entity;

public enum  ROLE {
    USER,GUEST,ADMIN
}
