package com.project.chawchaw.dto.social;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.context.annotation.Profile;

@Getter
@Setter
@ToString
public class KakaoProfile {
    private String email;
    private String name;
    private String provider;
    private String imageUrl;




    }





