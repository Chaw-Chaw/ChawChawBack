package com.project.chawchaw.dto.like;

public enum LikeType {
    LIKE,UNLIKE
}
