package com.project.chawchaw.dto.chat;

public enum MessageType {
    ENTER,TALK,EXIT,IMAGE
}
