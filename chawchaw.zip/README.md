# ChawChaw Back-End

## Deployment

- 접속 URL : https://chawchaw.vercel.app/
- 테스트 ID : test0@naver.com, test1@naver.com ··· test19@naver.com
- 테스트 PW : sssssssS1!
